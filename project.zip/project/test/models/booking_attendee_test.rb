require 'test_helper'

class BookingAttendeeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
