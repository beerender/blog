require 'test_helper'

class SendEmailJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
