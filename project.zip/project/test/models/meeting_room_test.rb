require 'test_helper'

class MeetingRoomTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
